import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class cli {
    public static void main(String[] args) {
        try (
                Socket socket = new Socket("localhost", 5555);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))
        ) {
            String userInput;
            System.out.println("Type messages, 'bye' to end");

            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput);

                String response = in.readLine();
                System.out.println("Received: " + response);

                if (userInput.startsWith("PUTFILE ")) {
                    String filename = userInput.split(" ")[1];
                    File file = new File(filename);
                    byte[] fileBytes = new byte[(int) file.length()];

                    try (FileInputStream fis = new FileInputStream(file)) {
                        fis.read(fileBytes);
                    }

                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                    dos.writeInt(fileBytes.length);
                    dos.write(fileBytes);
                } else if (userInput.startsWith("GETFILE ")) {
                    int fileId = Integer.parseInt(userInput.substring(8));
                    String fileLine = response;

                    if (!fileLine.startsWith("FILE")) {
                        continue;
                    }

                    String[] fileCommand = fileLine.split(" ", 4);
                    String filename = fileCommand[2];
                    int fileSize = Integer.parseInt(fileCommand[3]);

                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    byte[] fileBytes = new byte[fileSize];
                    dis.readFully(fileBytes);

                    try (FileOutputStream fos = new FileOutputStream(filename)) {
                        fos.write(fileBytes);
                    }
                }

                if (userInput.equals("bye")) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}