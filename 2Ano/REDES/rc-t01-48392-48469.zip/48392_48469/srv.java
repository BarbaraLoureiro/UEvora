import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class srv implements Serializable {
    private static final long serialVersionUID = 1L;
    private static LocalDateTime classStartTime;
    private static LinkedHashMap<String, String> presenceRecord = new LinkedHashMap<>();
    private static ArrayList<Question> questions = new ArrayList<>();
    private static String currentUser = "";
    private static ArrayList<FileData> files = new ArrayList<>();

    public static void main(String[] args) {
        loadData();
        classStartTime = LocalDateTime.now();

        try (ServerSocket serverSocket = new ServerSocket(5555)) {
            System.out.println("Waiting for connection...");

            while (true) {
                final Socket clientSocket = serverSocket.accept();
                System.out.println("Connection successful");

                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Could not listen on port: 9000.");
            System.exit(1);
        }
    }

    private static void handleClient(Socket clientSocket) {
        PrintWriter out = null;
        BufferedReader in = null;
        String currentUser = "";
        try {
            System.out.println("Waiting for input...");

            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String userLine;
            while ((userLine = in.readLine()) != null) {
                String[] command = userLine.split(" ", 2);

                if (command[0].equals("IAM")) {
                    if (command.length > 1) {
                        currentUser = command[1];
                        String presence = checkPresence(classStartTime, LocalDateTime.now());
                        presenceRecord.put(currentUser, presence);
                        out.println("HELLO " + currentUser);
                    }
                } else if (command[0].equals("ASK")) {

                    if (command.length > 1 && !command[1].trim().isEmpty()) {
                        String question = command[1];
                        questions.add(new Question(question));
                        out.println("QUESTION " + questions.size() + ": " + question);
                    } else {
                        out.println("ERROR: No question provided.");
                    }
                    out.println("ENDRESPONSE");
                }

                else if (command[0].equals("ANSWER")) {
                    if (command.length > 1) {
                        String[] answerCommand = command[1].split(" ", 2);
                        try {
                            int questionNumber = Integer.parseInt(answerCommand[0]);
                            String answer = answerCommand[1];
                            questions.get(questionNumber - 1).answers.put(currentUser, answer);
                            out.println("REGISTERED " + questionNumber);
                        } catch (NumberFormatException e) {
                            out.println("ERROR: Question number should be an integer.");
                        }
                    }
                } else if (command[0].equals("LISTQUESTIONS")) {
                    for (int i = 0; i < questions.size(); i++) {
                        Question q = questions.get(i);
                        out.println("(" + (i + 1) + ") " + q.question);
                        for (String answerUser : q.answers.keySet()) {
                            out.println("(" + answerUser + ") " + q.answers.get(answerUser));
                        }
                        if (q.answers.isEmpty()) {
                            out.println("NOTANSWERED");
                        }
                    }
                    out.println("ENDQUESTIONS");
                } else if (command[0].equals("PUTFILE")) {
                    String[] putfileCommand = command[1].split(" ", 2);
                    String filename = putfileCommand[0];
                    int filesize = Integer.parseInt(putfileCommand[1]);

                    InputStream is = clientSocket.getInputStream();
                    byte[] fileContent = new byte[filesize];
                    int count, total = 0;
                    System.out.println(filesize);
                    while (total < filesize && (count = is.read(fileContent, total, filesize - total)) > 0) {
                        total += count;
                        System.out.println(count);
                        System.out.println(total);
                    }

                    FileData fileData = new FileData(filename, fileContent);
                    files.add(fileData);

                    out.println("UPLOADED " + filename);
                } else if (command[0].equals("LISTFILES")) {
                    for (int i = 0; i < files.size(); i++) {
                        FileData fileData = files.get(i);
                        out.println("(" + (i + 1) + ") " + fileData.filename);
                    }
                    out.println("ENDFILES");
                } else if (command[0].equals("GETFILE")) {
                    int fileIndex = Integer.parseInt(command[1]);
                    if (fileIndex < 1 || fileIndex > files.size()) {
                        out.println("ERROR: Invalid file index.");
                        continue;
                    }

                    FileData fileData = files.get(fileIndex - 1);
                    out.println("FILE " + fileIndex + " " + fileData.filename + " " + fileData.content.length);
                    out.flush();

                    OutputStream os = clientSocket.getOutputStream();
                    os.write(fileData.content);
                    os.flush();
                } else if (command[0].equals("RESET")) {
                    questions.clear();
                    files.clear();
                    presenceRecord.clear();
                    saveData();
                    out.println("Server data reset.");
                }

                else {
                    System.out.println("Server: " + userLine);
                    out.println(userLine);
                }
            }

        } catch (

        IOException e) {
            System.err.println("I/O error with the connection to the client");
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
                if (clientSocket != null) {
                    clientSocket.close();
                }
                saveData();
            } catch (IOException e) {
                System.err.println("Error closing the connection sockets");
            }
        }
    }

    private static String checkPresence(LocalDateTime classStartTime, LocalDateTime loginTime) {
        long diffInMinutes = Duration.between(classStartTime, loginTime).toMinutes();
        if (diffInMinutes < 20) {
            return "Full presence";
        } else if (diffInMinutes < 45) {
            return "Half presence";
        } else {
            return "No presence";
        }
    }

    private static class Question implements Serializable {
        private static final long serialVersionUID = 1L;
        String question;
        LinkedHashMap<String, String> answers = new LinkedHashMap<>();

        Question(String question) {
            this.question = question;
        }
    }

    private static class FileData implements Serializable {
        private static final long serialVersionUID = 1L;
        String filename;
        byte[] content;

        FileData(String filename, byte[] content) {
            this.filename = filename;
            this.content = content;
        }
    }

    private static void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("serverData.ser"))) {
            oos.writeObject(questions);
            oos.writeObject(files);
            oos.writeObject(presenceRecord);
            oos.writeObject(currentUser);
            oos.writeObject(classStartTime);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadData() {
        File dataFile = new File("serverData.ser");
        if (dataFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(dataFile))) {
                questions = (ArrayList<Question>) ois.readObject();
                files = (ArrayList<FileData>) ois.readObject();
                presenceRecord = (LinkedHashMap<String, String>) ois.readObject();
                currentUser = (String) ois.readObject();
                classStartTime = (LocalDateTime) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            // If no saved data, set the start time to now
            classStartTime = LocalDateTime.now();
        }
    }
}