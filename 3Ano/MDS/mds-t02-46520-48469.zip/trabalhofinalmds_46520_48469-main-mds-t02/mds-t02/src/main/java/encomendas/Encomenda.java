/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package encomendas;

/**
 *
 * @author carlos
 */

import artigos_menus.Artigo;
import artigos_menus.Menu;
import clientes.Cliente;
import java.util.ArrayList;
import java.util.List;

public class Encomenda {

    private int id;
    private Cliente cliente;
    private List<Artigo> artigos;
    private double precoTotal;
    private String estado;

    public Encomenda(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
        this.artigos = new ArrayList<>();
        this.precoTotal = 0;
        this.estado = "pendente";
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<Artigo> getArtigos() {
        return artigos;
    }

    public double getPrecoTotal() {
        return precoTotal;
    }

    public String getEstado() {
        return estado;
    }

    public void adicionarArtigo(Artigo artigo) {
        artigos.add(artigo);
        precoTotal += artigo.getPreco();
    }

    public void removerArtigo(Artigo artigo) {
        artigos.remove(artigo);
        precoTotal -= artigo.getPreco();
    }
    
    public void adicionarMenu(Menu menu){
        List <Artigo> menu1=menu.getArtigosMenu();
        
        for(int i=0;i<menu1.size();i++){
            adicionarArtigo(menu1.get(i));
        }
    }
    
    public void removerMenu(Menu menu){
        List <Artigo> menu1=menu.getArtigosMenu();
        
        for(int i=0;i<menu1.size();i++){
            removerArtigo(menu1.get(i));
        }
    }
    
    public List<Artigo> getArtigosEncomenda(){
        return artigos;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
