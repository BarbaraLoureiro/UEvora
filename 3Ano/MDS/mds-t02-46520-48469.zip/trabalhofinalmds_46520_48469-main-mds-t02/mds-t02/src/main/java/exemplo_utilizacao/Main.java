/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemplo_utilizacao;

import api.API;
import java.util.Scanner;

/**
 *
 * @author carlos
 */
public class Main {
      
    private static API api;
    
    public static int menuPrincipal(){
       Scanner s=new Scanner(System.in);

       System.out.println("\nIndique o tipo de utilizador:");
       System.out.println("1- Cliente");
       System.out.println("2- Restaurante");
       System.out.println("3- Administrador");
       System.out.println("4- Sair");
       System.out.print("Opção: ");
       int op=s.nextInt();
              
       return op;
    }
    
    public static int menuCliente(){
        Scanner s=new Scanner(System.in);
        
        System.out.println("\nOpções:");
        System.out.println("1- Criar Cliente");
        System.out.println("2- Mostrar Restaurantes");
        System.out.println("3- Mostrar Menus");
        System.out.println("4- Adicionar artigos à encomenda");
        System.out.println("5-Remover artigos encomenda");
        System.out.println("6- Cancelar uma encomenda");
        System.out.println("7- Confirmar uma encomenda");

        System.out.println("8- Sair");  
       
        System.out.print("Opção: ");
        int op = s.nextInt();
        

        return op;
    }
    
    public static int menuRestaurante(){
        Scanner s=new Scanner(System.in);
        
        System.out.println("\nOpções:");
        System.out.println("1- Criar Artigo");
        System.out.println("2- Criar Menu");
        System.out.println("3- Adicionar Artigo a Menu");
        System.out.println("4- Adicionar Menu a Restaurante");

        System.out.println("5- Sair");  
       
        System.out.print("Opção: ");
        int op = s.nextInt();

        return op;
        
    }
    
    public static int menuAdmin(){
        Scanner s=new Scanner(System.in);
        
        System.out.println("\nOpções:");
        System.out.println("1- Remover Utilizador");
        System.out.println("2- Criar Restaurante");
        System.out.println("3- Remover Restaurante");

        System.out.println("4- Sair");  
       
        System.out.print("Opção: ");
        int op = s.nextInt();

        return op;
    }
    
    
    
    public static void main(String[] args) {
       api = new API(); 
       Scanner s= new Scanner(System.in);
       
       while(true){
       int op=menuPrincipal();
       
       if(op==1){
           while(true){
           int option=menuCliente();
           
           switch(option){
               
               //Criar cliente
               case 1:
                   System.out.println("Indique um username: ");
                   String username=s.nextLine();
                   System.out.println("Indique o nome completo: ");
                   String nome=s.nextLine();
                   System.out.println("Indique o email: ");
                   String email=s.nextLine();
                   System.out.println("Indique o contacto ");
                   int contacto=s.nextInt();
                   s.nextLine();
                   api.criarCliente(username, nome, email, contacto);
                   
                   System.out.println("USERNAME: "+username);
                break;
                
                //Mostrar restaurantes
               case 2:
                   System.out.println(api.getNomeRestaurantes());
                break;                       
                   
                //Mostrar menus 
               case 3:
                   System.out.println("Indique o restaurante: ");
                   String restaurante=s.nextLine();
                   api.printMenusRestaurante(restaurante);
                break;
                   
                //Adicionar artigos à encomenda
               case 4:
                    System.out.println("Indique o seu username: ");
                    String user=s.nextLine();
                    int id_encomenda=api.criarEncomenda(user);
                    System.out.println("Encomenda criada com o numero "+id_encomenda);
                    while(true){
                    System.out.println("Indique o artigo que pretende adicionar(Se não pretender mais nenhum prima 0): ");
                    String artigo=s.nextLine();
                    
                    if(artigo.equals("0")) break;
                    
                    api.adicionarArtigodaEncomenda(id_encomenda, artigo);
                    }
                    
                break;
                
                //Remover artigos de encomenda
               case 5:
                    System.out.println("Indique o numero da encomenda: ");
                    int id_encomenda1=s.nextInt();
                    s.nextLine();
                    while(true){
                    System.out.println("Indique o artigo que pretende remover(Se não pretender mais nenhum prima 0): ");
                    String artigo1=s.nextLine();
                    
                    if(artigo1.equals("0")) break;
                    
                    api.removerArtigodaEncomenda(id_encomenda1, artigo1);
                    }
               
               break;
               
                //Cancelar uma encomenda
               case 6:
                   System.out.println("Indique o numero da encomenda que pretende cancelar");
                   int idc=s.nextInt();
                   api.cancelarEncomenda(idc);
                   
                break;
                   
                //Confirmar encomenda
               case 7:
                   System.out.println("Indique o numero da encomenda que pretende confirmar");
                   int id=s.nextInt();
                   api.realizarEncomenda(id);

                break;
                   
               default:
                   System.out.println("Opção não válida");
           }
           if(option==8) break;
           }
           
       }else if(op==2){
           while(true){
               int option=menuRestaurante();
               switch(option){
                   //Criar artigo
                   case 1:
                       System.out.println("Indique o nome do artigo: ");
                       String nome_artigo=s.nextLine();
                       System.out.println("Indique a descrição do artigo: ");
                       String descricao=s.nextLine();
                       System.out.println("Indique o preço: ");
                       double preco=s.nextDouble();
                       s.nextLine();
                       api.criarArtigo(nome_artigo, descricao, preco);

                   break;
                   //Criar menu
                   case 2:
                       System.out.println("Indique o nome do menu: ");
                       String nome_menu=s.nextLine();
                       api.criarMenu(nome_menu);
                       
                   break;
                   //Adicionar artigo a menu
                   case 3:
                       System.out.println("Indique o nome do menu: ");
                       String nome_menu1=s.nextLine();
                       System.out.println("Indique o nome do artigo: ");
                       String nome_artigo1=s.nextLine();
                       api.adicionarArtigoMenu(nome_menu1, nome_artigo1);
                       
                   break;
                   //Adicionar menu a restaurante
                   case 4:
                       System.out.println("Indique o Restaurante: ");
                       String restaurante=s.nextLine();
                       System.out.println("Indique o menu: ");
                       String menu=s.nextLine();
                       api.adicionarMenuRestaurante(restaurante, menu);
                   break;
                   
                   default:
                       System.out.println("Opção não válida");
               }
               if(option==5) break;  
           }
           
       }else if(op==3){
           while(true){
               int option=menuAdmin();
               
               switch(option){
                   //Remover cliente
                   case 1:
                       System.out.println("Indique o username do cliente que pretende remover: ");
                       String user=s.nextLine();
                       
                       api.removerCliente(user);
                       
                   break;
                   
                   //Criar restaurante
                   case 2:
                       System.out.println("Indique o nome do restaurante: ");
                       String nome=s.nextLine();
                       System.out.println("Indique a morada: ");
                       String morada=s.nextLine();
                       System.out.println("Indique o contacto");
                       int contacto=s.nextInt();
                       s.nextLine();
                       System.out.println("Indiue o horario");
                       String horario=s.nextLine();
                       api.adicionarRestaurante(nome, morada, contacto, horario);
                   break;
                   
                   //Remover restaurante
                   case 3:
                       System.out.println("Indique o nome do restaurante que pretende remover: ");
                       String nome_restaurante=s.nextLine();
                       api.removerRestaurante(nome_restaurante);
                   break;
                   
                   default:
                       System.out.println("Opção não válida");
               }
               
               if(option==4)  break;
           }
           
       }else if(op==4){
           System.exit(0);
       }else{
           System.out.println("Opção não é válida");
       }
    }
    }
}
