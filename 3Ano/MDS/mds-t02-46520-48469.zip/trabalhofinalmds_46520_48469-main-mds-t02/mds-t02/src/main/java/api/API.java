/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package api;

import artigos_menus.Artigo;
import artigos_menus.ArtigoOp;
import artigos_menus.Menu;
import artigos_menus.MenuOp;
import clientes.Cliente;
import clientes.ClienteOp;
import encomendas.Encomenda;
import encomendas.EncomendaOp;
import java.util.LinkedList;
import java.util.List;
import restaurantes.Restaurante;
import restaurantes.RestauranteOp;

/**
 *
 * @author carlos
 */

//Interface publica para a biblioteca

public class API {
    
    private RestauranteOp gerenciador_restaurantes;
    private ArtigoOp gerenciador_artigos;
    private MenuOp gerenciador_menus;
    private ClienteOp gerenciador_clientes;
    private EncomendaOp gerenciador_encomendas;

    public API() {
        this.gerenciador_restaurantes = new RestauranteOp();
        this.gerenciador_artigos= new ArtigoOp();
        this.gerenciador_menus= new MenuOp();
        this.gerenciador_clientes= new ClienteOp();
        this.gerenciador_encomendas= new EncomendaOp();
    }
    
    //Restaurantes
    public void adicionarRestaurante(String nome, String morada, int contacto, String horario) {
        Restaurante restaurante = new Restaurante(nome, morada, contacto, horario);
        gerenciador_restaurantes.criarRestaurante(restaurante);
        
        System.out.println("Restaurante adicionado com sucesso");
    }

    public void editarRestaurante(String antigoNome, String novoNome, String novaMorada, int novoContacto, String novoHorario) {
        gerenciador_restaurantes.editarRestaurante(antigoNome, novoNome, novaMorada, novoContacto, novoHorario);
        
        System.out.println("Restaurante editado com sucesso");

    }

    public void removerRestaurante(String restaurante) {
        gerenciador_restaurantes.removerRestaurante(restaurante);
        
        System.out.println("Restaurante removido com sucesso");

    }

    public List<Restaurante> getRestaurantes() {
        return gerenciador_restaurantes.getRestaurantes();
    }
    
    public List<String> getNomeRestaurantes(){
        List<Restaurante> restaurantes=gerenciador_restaurantes.getRestaurantes();
        List<String> nome_restaurantes=new LinkedList<>();
        
        for(int i=0;i<restaurantes.size();i++){
            nome_restaurantes.add(restaurantes.get(i).getNome());
        }
        
        return nome_restaurantes;
    }
    
    public void adicionarMenuRestaurante(String restaurante,String menu){
        List<Menu> menus=gerenciador_menus.getMenus();
        
        for(int i=0;i<menus.size();i++){
            if(menus.get(i).getNome().equals(menu)){
                gerenciador_restaurantes.adicionarMenu(restaurante,menus.get(i));
                System.out.println("Menu adicionado ao restaurante com sucesso");
            }else{
                System.out.println("O menu não existe no sistema");
            }
        }
    }
    
     public void removerMenuRestaurante(String restaurante,String menu){
        List<Menu> menus=gerenciador_menus.getMenus();
        
        for(int i=0;i<menus.size();i++){
            if(menus.get(i).getNome().equals(menu)){
                gerenciador_restaurantes.removerMenu(restaurante,menus.get(i));
                System.out.println("Menu removido do restaurante com sucesso");
            }else{
                System.out.println("O menu não existe no sistema");
            }
        }
    }
    
    public List<Menu> obterMenusDeRestaurante(String restaurante){
        return gerenciador_restaurantes.getMenusPorRestaurante(restaurante);
    }
    
    public void printMenusRestaurante(String restaurante){
        List<String> nomes_restaurantes=getNomeRestaurantes();
        
        int count=0;
        for(int i=0;i<nomes_restaurantes.size();i++){
            if(nomes_restaurantes.get(i).equals(restaurante)){
                count=1;
            }
        }
        
        if(count==1){
        List<Menu> menus=gerenciador_restaurantes.getMenusPorRestaurante(restaurante);
        
        for(int i=0;i<menus.size();i++){
            String nome_menu=menus.get(i).getNome();
            System.out.println(nome_menu+": ");
            List<Artigo> artigos=gerenciador_menus.getArtigos(nome_menu);
            for(int j=0;j<artigos.size();j++){
                System.out.println(artigos.get(j).getNome());
            }
        }
        }else{
            System.out.println("O restaurante não existe");
        }
    }
    
    
    //Artigos
    public void criarArtigo(String nome, String descricao, double preco){
        Artigo artigo = new Artigo(nome,descricao,preco);
        gerenciador_artigos.criarArtigo(artigo);
        
        System.out.println("Artigo criado com sucesso ");
    }
    
    public void editarArtigo(String antigoNome, String novoNome, String novadescricao, double preco){
        gerenciador_artigos.editarArtigo(antigoNome, novoNome, novadescricao, preco);
    
        System.out.println("Artigo editado com sucesso");
    }
    
    public void removerArtigo(String artigo){
        gerenciador_artigos.removerArtigo(artigo);
        
        System.out.println("Artigo removido com sucesso");
    }
    
    public List<Artigo> getArtigos(){
        return gerenciador_artigos.getArtigos();
    }
    
    //Menus
    public void criarMenu(String nome){
        gerenciador_menus.criarMenu(nome);
        
        System.out.println("Menu criado com sucesso");
    }
    
    public void editarNomeMenu(String antigoNome, String novoNome){
        gerenciador_menus.editarMenu(antigoNome, novoNome);
        
        System.out.println("Nome do menu editado com sucesso");
    }
    
    public void removerMenu(String nome){
        gerenciador_menus.removerMenu(nome);
        
        System.out.println("Menu removido com sucesso");
    }
    
    public void adicionarArtigoMenu(String menu, String artigo){
        List<Artigo> artigos=gerenciador_artigos.getArtigos();
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(artigo)){
                gerenciador_menus.adicionarArtigoAoMenu(menu,artigos.get(i));
                System.out.println("Artigo adicionado ao menu com sucesso");
            }else{
                System.out.println("O artigo não existe no sistema");
            }
        }   
    }
    
    public void removerArtigoMenu(String menu, String artigo){
        List<Artigo> artigos=gerenciador_artigos.getArtigos();
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(artigo)){
                gerenciador_menus.removerArtigoDoMenu(menu,artigos.get(i));
                System.out.println("Artigo removido do menu com sucesso");
            }else{
                System.out.println("O artigo não existe no sistema");
            }
        }
    }
    
    public List<Menu> getMenus(){
       return gerenciador_menus.getMenus();
    }
    
    //Clientes
    public void criarCliente(String username, String nome_completo, String email, int contacto){
        Cliente cliente=new Cliente(username,nome_completo,email,contacto);
        gerenciador_clientes.criarCliente(cliente);
    }
    
    public void editarCliente(String antigoUsername, String novoUsername,String novoNomeCompleto, String novoEmail, int novoContacto){
        gerenciador_clientes.editarCliente(antigoUsername, novoUsername, novoNomeCompleto, novoContacto, novoEmail);
    }
    
    public void removerCliente(String username){
        gerenciador_clientes.removerCliente(username);
    }
    
    public List<Cliente> getClientes(){
        return gerenciador_clientes.getClientes();
    }
    
    //Encomendas
    public int criarEncomenda(String username){
        List<Cliente> clientes=gerenciador_clientes.getClientes();
        int id=0;
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getUsername().equals(username)){
                id=gerenciador_encomendas.criarEncomenda(clientes.get(i));
                System.out.println("Encomenda criada com sucesso");
            }else{
                System.out.println("Cliente não existe no sistema");
            }
        }
        
        return id;
    }
    
    public void adicionarArtigodaEncomenda(int id, String artigo){
        List<Artigo> artigos=gerenciador_artigos.getArtigos();
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(artigo)){
                gerenciador_encomendas.adicionarArtigoEncomenda(id,artigos.get(i));
                System.out.println("Artigo adicionado à encomenda com sucesso");
            }else{
                System.out.println("O artigo não existe no sistema");
            }
        }   
    }
    
    public void removerArtigodaEncomenda(int id, String artigo){
        List<Artigo> artigos=gerenciador_artigos.getArtigos();
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(artigo)){
                gerenciador_encomendas.removerArtigoEncomenda(id,artigos.get(i));
                System.out.println("Artigo removido da encomenda com sucesso");
            }else{
                System.out.println("O artigo não existe no sistema");
            }
        }   
    }
    
    public List<Artigo> obterArtigosEncomenda(int id){
        return gerenciador_encomendas.getArtigosEncomenda(id);
    }
    
    public void cancelarEncomenda(int id){
        gerenciador_encomendas.removerEncomenda(id);
        System.out.println("Encomenda cancelada com sucesso");
    }
    
    public List<Encomenda> obterEncomendas(){
        return gerenciador_encomendas.getEncomendas();
    }
    
    public void realizarEncomenda(int id){
        gerenciador_encomendas.changeEstado(id,"Preparação");
        System.out.println("Encomenda realizada e em preparação");
    }
    
    public void concluirEncomenda(int id){
        gerenciador_encomendas.changeEstado(id, "Concluido");
        System.out.println("Encomenda concluida");
    }
}