/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package encomendas;

import artigos_menus.Artigo;
import artigos_menus.Menu;
import clientes.Cliente;
import java.util.*;

/**
 *
 * @author carlos
 */
public class EncomendaOp {
    private List<Encomenda> encomendas;
    
    public EncomendaOp(){
        this.encomendas= new LinkedList<>();
    }
    
    public int criarEncomenda(Cliente cliente) {
        int id=encomendas.size();
        Encomenda encomenda = new Encomenda(id,cliente);
        encomendas.add(encomenda);
        
        return id;
    }
    
    public void adicionarArtigoEncomenda(int idEncomenda, Artigo artigo){
        encomendas.get(idEncomenda).adicionarArtigo(artigo);
    }
    
    public void removerArtigoEncomenda(int idEncomenda, Artigo artigo){
        encomendas.get(idEncomenda).removerArtigo(artigo);
    }
    
    public List<Artigo> getArtigosEncomenda(int idEncomenda){
        return encomendas.get(idEncomenda).getArtigosEncomenda();
    }
    
    public void adicionarMenuEncomenda(int idEncomenda, Menu menu){
        encomendas.get(idEncomenda).adicionarMenu(menu);
    }
    
    public void removerMenuEncomenda(int idEncomenda, Menu menu){
        encomendas.get(idEncomenda).removerMenu(menu);
    }
    
    public void removerEncomenda(int idEncomenda){
        encomendas.remove(idEncomenda);
    }
    
    public List<Encomenda> getEncomendas() {
        return encomendas;
    }
    
    public void changeEstado(int idEncomenda,String estado){
        encomendas.get(idEncomenda).setEstado(estado);
    }
    
}
