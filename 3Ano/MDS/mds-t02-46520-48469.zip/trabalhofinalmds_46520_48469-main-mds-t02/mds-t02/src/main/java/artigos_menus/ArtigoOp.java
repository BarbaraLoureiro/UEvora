/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package artigos_menus;

import java.util.*;

/**
 *
 * @author carlos
 */
public class ArtigoOp {
    
    private static ArrayList<Artigo> artigos;
    
    public  ArtigoOp(){
        artigos=new ArrayList<>();
    }
    
    public void criarArtigo(Artigo a){
        artigos.add(a);
    }
    
    public void editarArtigo(String antigoNome, String novoNome, String novadescricao, double novopreco) {
        Artigo artigo = null;
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(antigoNome)){
                artigo=artigos.get(i);
            }
        }
        
        artigo.setNome(novoNome);
        artigo.setDescricao(novadescricao);
        artigo.setPreco(novopreco);
    } 
    
    public void removerArtigo(String artigo2) {
        Artigo artigo = null;
        
        for(int i=0;i<artigos.size();i++){
            if(artigos.get(i).getNome().equals(artigo2)){
                artigo=artigos.get(i);
            }
        }
        
        artigos.remove(artigo);
    }
    
    public ArrayList<Artigo> getArtigos(){
        return this.artigos;
    }
    
}
