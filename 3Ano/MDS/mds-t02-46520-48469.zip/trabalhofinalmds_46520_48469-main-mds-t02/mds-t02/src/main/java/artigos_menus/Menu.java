/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package artigos_menus;

import java.util.*;

/**
 *
 * @author carlos
 */

public class Menu {
    private static String nome;
    private static List<Artigo> artigos;

    public Menu(String nome) {
        this.nome = nome;
        this.artigos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void adicionarArtigo(Artigo artigo) {
        artigos.add(artigo);
    }

    public void removerArtigo(Artigo artigo) {
        artigos.remove(artigo);
    }

    public List<Artigo> getArtigosMenu() {
        return artigos;
    }
}