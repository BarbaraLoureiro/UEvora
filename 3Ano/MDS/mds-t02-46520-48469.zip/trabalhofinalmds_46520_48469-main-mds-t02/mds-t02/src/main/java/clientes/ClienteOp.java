/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clientes;

import java.util.*;

/**
 *
 * @author carlos
 */

//Operações relativas a clientes
public class ClienteOp {
    
    private static ArrayList <Cliente> clientes;
    
    public ClienteOp(){
        clientes=new ArrayList<>();
    }
    
    
    
    public void criarCliente(Cliente cliente){
        
    this.clientes.add(cliente);
        
    }
    
    public void editarCliente(String antigoUsername, String novoUsername, String novoNome_completo, int novoContacto, String novoEmail) {
        Cliente cliente = null;
        
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getUsername().equals(antigoUsername)){
                cliente=clientes.get(i);
            }
        }
        
        cliente.setUsername(novoUsername);
        cliente.setNome_completo(novoNome_completo);
        cliente.setEmail(novoEmail);
        cliente.setContacto(novoContacto);
    }
    
    public void removerCliente(String username) {
        Cliente cliente = null;
        
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getUsername().equals(username)){
                cliente=clientes.get(i);
            }
        }
        
        clientes.remove(cliente);
    }
    
    public ArrayList <Cliente> getClientes(){
        return this.clientes;
    }
    
}
