/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restaurantes;

import artigos_menus.Menu;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlos
 */

//Classe para representar o restaurante

public class Restaurante {
    
    private static String nome;
    private static String morada;
    private static int contacto;
    private static String horario;
    private static List<Menu> menus;
    
    public Restaurante(String nome,String morada,int contacto, String horario){
        this.nome=nome;
        this.morada=morada;
        this.contacto=contacto;
        this.horario=horario;
        this.menus=new ArrayList<>();
    }
    
    public void setNome(String nome){
        this.nome=nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setMorada(String morada){
        this.morada=morada;
    }
    
    public String getMorada(){
        return morada;
    }
    
    public void setContacto(int contacto){
        this.contacto=contacto;
    }
    
    public int getContacto(){
        return contacto;
    }
    
    public void setHorario(String horario){
        this.horario=horario;
    }
    
    public String getHorario(){
        return horario;
    }
    
    public void addMenu(Menu menu){
        menus.add(menu);
    }
    
    public void removeMenu(Menu menu){
        menus.remove(menu);
    }
    
    public List<Menu> getMenus(){
        return menus;
    }
    
}
