/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package artigos_menus;

import java.util.*;

/**
 *
 * @author carlos
 */
public class MenuOp {
    
  private List<Menu> menus;

    public MenuOp() {
        this.menus = new ArrayList<>();
    }

    public void criarMenu(String nome) {
        Menu menu = new Menu(nome);
        menus.add(menu);
    }

    public void editarMenu(String antigoNome, String novoNome) {
        for (Menu menu : menus) {
            if (menu.getNome().equals(antigoNome)) {
                menu.setNome(novoNome);
                break;
            }
        }
    }

    public void removerMenu(String nome) {
        for (Menu menu : menus) {
            if (menu.getNome().equals(nome)) {
                menus.remove(menu);
                break;
            }
        }
    }

    public void adicionarArtigoAoMenu(String menu, Artigo artigo) {
        for (Menu m : menus) {
            if (m.getNome().equals(menu)) {
                m.adicionarArtigo(artigo);
                break;
            }
        }
    }

    public void removerArtigoDoMenu(String menu, Artigo artigo) {
        for (Menu m : menus) {
            if (m.getNome().equals(menu)) {
                m.removerArtigo(artigo);
                break;
            }
        }
    }

    public List<Menu> getMenus() {
        return menus;
    }
    
    public List<Artigo> getArtigos(String nome){
        Menu menun=null;
        for (Menu menu : menus) {
            if (menu.getNome().equals(nome)) {
                menun=menu;
                break;
            }
        }
        
        return menun.getArtigosMenu();
    }
}


