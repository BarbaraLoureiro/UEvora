/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Artigo to edit this template
 */
package artigos_menus;

/**
 *
 * @author carlos
 */

public class Artigo {
    
    private static String nome;
    private static String descricao;
    private static double preco;
    
    public Artigo(String nome, String descricao, double preco){
        this.nome=nome;
        this.descricao=descricao;
        this.preco=preco;
    }
    
    public void setNome(String nome){
        this.nome=nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setDescricao(String descricao){
        this.descricao=descricao;
    }
    
    public String getDescricao(){
        return descricao;
    }
    
    public void setPreco(double preco){
        this.preco=preco;
    }
    
    public double getPreco(){
        return preco;
    }
}
