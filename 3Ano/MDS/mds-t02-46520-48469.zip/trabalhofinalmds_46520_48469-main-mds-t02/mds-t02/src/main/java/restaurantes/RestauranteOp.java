/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restaurantes;

import artigos_menus.Menu;
import java.util.*;

/**
 *
 * @author carlos
 */

//Operações relativas a restaurantes

public class RestauranteOp {
    
    private static ArrayList <Restaurante> restaurantes ;
    
    public RestauranteOp(){
        this.restaurantes = new ArrayList<>();
    }
    
    
    public void criarRestaurante(Restaurante restaurante){
        
    this.restaurantes.add(restaurante);
        
    }
    
    public void editarRestaurante(String antigoNome, String novoNome, String novaMorada, int novoContacto, String novoHorario) {
        Restaurante restaurante = null;
        
        for(int i=0;i<restaurantes.size();i++){
            if(restaurantes.get(i).getNome().equals(antigoNome)){
                restaurante=restaurantes.get(i);
            }
        }
        
        restaurante.setNome(novoNome);
        restaurante.setMorada(novaMorada);
        restaurante.setContacto(novoContacto);
        restaurante.setHorario(novoHorario);
    }
    
    public void removerRestaurante(String restauranter) {
        Restaurante restaurante = null;
        
        for(int i=0;i<restaurantes.size();i++){
            if(restaurantes.get(i).getNome().equals(restauranter)){
                restaurante=restaurantes.get(i);
            }
        }
        
        restaurantes.remove(restaurante);
    }
    
    public void adicionarMenu(String restauranter,Menu menu){
        Restaurante restaurante = null;
        Menu menu1=null;
        
        for(int i=0;i<restaurantes.size();i++){
            if(restaurantes.get(i).getNome().equals(restauranter)){
                restaurante=restaurantes.get(i);
            }
        }
        
        restaurante.addMenu(menu);
    }
    
    public void removerMenu(String restauranter,Menu menu){
        Restaurante restaurante = null;
        Menu menu1=null;
        
        for(int i=0;i<restaurantes.size();i++){
            if(restaurantes.get(i).getNome().equals(restauranter)){
                restaurante=restaurantes.get(i);
            }
        }
        
        restaurante.removeMenu(menu);
    }
    
    public List<Menu> getMenusPorRestaurante(String restauranter){
        Restaurante restaurante = null;
        
        for(int i=0;i<restaurantes.size();i++){
            if(restaurantes.get(i).getNome().equals(restauranter)){
                restaurante=restaurantes.get(i);
            }
        }
        
        return restaurante.getMenus();
    }
    
    public ArrayList <Restaurante> getRestaurantes(){
        return this.restaurantes;
    }
}
