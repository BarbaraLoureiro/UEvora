/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clientes;

/**
 *
 * @author carlos
 */
public class Cliente {
    
    private static String username;
    private static String nome_completo;
    private static String email;
    private static int contacto;
    
    public Cliente (String username, String nome_completo, String email, int contacto){
        this.username=username;
        this.nome_completo=nome_completo;
        this.email=email;
        this.contacto=contacto;
    }
    
    public void setUsername(String username){
        this.username=username;
    }
    
    public String getUsername(){
        return username;
    }
    
    public void setNome_completo(String nome_completo){
        this.nome_completo=nome_completo;
    }
    
    public String getNome_completo(){
        return nome_completo;
    }
    
    public void setEmail(String email){
        this.email=email;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setContacto(int contacto){
        this.contacto=contacto;
    }
    
    public int getContacto(){
        return contacto;
    }
    
}
