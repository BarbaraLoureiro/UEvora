/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testes_unitarios;

import api.API;
import artigos_menus.Artigo;
import java.util.*;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author carlos
 */
public class APITest_artigos {
     private API api;

    @Before
    public void setUp() {
        api = new API();
    }
    
    //Teste unitário para a criação de artigo
    @Test
    public void testCriarArtigo() {
        api.criarArtigo("hamburger",  "hamburger com queijo e bacon",10.50);
        List<Artigo> artigos = api.getArtigos();
        assertEquals(1, artigos.size());
        assertEquals("hamburger",artigos.get(0).getNome());
        assertEquals(10.50, artigos.get(0).getPreco(),0);
        assertEquals("hamburger com queijo e bacon", artigos.get(0).getDescricao());
    }
    
    //Teste unitário para a edição de um artigo
    @Test
    public void testEditarArtigo() {
        api.criarArtigo("hamburger", "hamburger com queijo e bacon", 10.50);
        api.editarArtigo("hamburger", "cheeseburger", "hamburger com queijo extra", 12.50);
        List<Artigo> artigos = api.getArtigos();
        assertEquals(1, artigos.size());
        assertEquals("cheeseburger", artigos.get(0).getNome());
        assertEquals(12.50, artigos.get(0).getPreco(), 0);
        assertEquals("hamburger com queijo extra", artigos.get(0).getDescricao());
    }
    
    //Teste unitário para verificar a remoção de um artigo
    @Test
    public void testRemoverArtigo() {
        api.criarArtigo("hamburger", "hamburger com queijo e bacon", 10.50);
        api.removerArtigo("hamburger");
        List<Artigo> artigos = api.getArtigos();
        assertEquals(0, artigos.size());
}
}
