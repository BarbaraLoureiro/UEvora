/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testes_unitarios;

import api.API;
import artigos_menus.Artigo;
import encomendas.Encomenda;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author carlos
 */
public class APITest_encomendas {
    private API api;

    @Before
    public void setUp() {
        api = new API();
    }
    
    //Teste unitário para verificar a criação de uma encomenda
    @Test
    public void testCriarEncomenda() {
        api.criarCliente("user1", "Nome Completo", "email@email.com", 123456);
        int id = api.criarEncomenda("user1");
        List<Encomenda> encomendas = api.obterEncomendas();
        assertEquals(1, encomendas.size());
        assertEquals("user1", encomendas.get(0).getCliente().getUsername());
    }
    
    //Teste unitário para verificar a adição de um artigo à encomenda
    @Test
    public void testAdicionarArtigoEncomenda() {
        api.criarCliente("user1", "Nome Completo", "email@email.com", 123456);
        api.criarArtigo("hamburger", "hamburger com queijo e bacon", 10.50);
        int id = api.criarEncomenda("user1");
        api.adicionarArtigodaEncomenda(id, "hamburger");
        List<Encomenda> encomendas = api.obterEncomendas();
        assertEquals(1, encomendas.get(0).getArtigos().size());
        assertEquals("hamburger", encomendas.get(0).getArtigos().get(0).getNome());
    }
    
    //Teste unitário para verificar a remoção de um artigo à encomenda
    @Test
    public void testRemoverArtigoEncomenda() {
        int id = api.criarEncomenda("username");
        api.adicionarArtigodaEncomenda(id, "hamburger");
        api.removerArtigodaEncomenda(id, "hamburger");
        List<Artigo> artigos = api.obterArtigosEncomenda(id);
        assertEquals(0, artigos.size());
    }
    
}
