/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testes_unitarios;

import api.API;
import clientes.Cliente;
import java.util.List;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author carlos
 */
public class APITest_clientes {
    private API api;

    @Before
    public void setUp() {
        api = new API();
    }
    
    //Teste unitário para a criação de clientes
    @Test
    public void testCriarCliente() {
        api.criarCliente("carlos", "Carlos Silva", "carlos@email.com", 123456789);
        List<Cliente> clientes = api.getClientes();
        assertEquals(1, clientes.size());
        assertEquals("carlos", clientes.get(0).getUsername());
        assertEquals("Carlos Silva", clientes.get(0).getNome_completo());
        assertEquals("carlos@email.com", clientes.get(0).getEmail());
        assertEquals(123456789, clientes.get(0).getContacto());
    }
    
    //Teste unitário para a edição dos clientes
    @Test
    public void testEditarCliente() {
        api.criarCliente("carlos", "Carlos Silva", "carlos@email.com", 123456789);
        api.editarCliente("carlos", "carlos2", "Carlos Silva 2", "carlos2@email.com", 987654321);
        List<Cliente> clientes = api.getClientes();
        assertEquals(1, clientes.size());
        assertEquals("carlos2", clientes.get(0).getUsername());
        assertEquals("Carlos Silva 2", clientes.get(0).getNome_completo());
        assertEquals("carlos2@email.com", clientes.get(0).getEmail());
        assertEquals(987654321, clientes.get(0).getContacto());
    }
    
    //Teste unitário para remover clientes
    @Test
    public void testRemoverCliente() {
        api.criarCliente("carlos", "Carlos Silva", "carlos@email.com", 123456789);
        api.removerCliente("carlos");
        List<Cliente> clientes = api.getClientes();
        assertEquals(0, clientes.size());
    }

}
