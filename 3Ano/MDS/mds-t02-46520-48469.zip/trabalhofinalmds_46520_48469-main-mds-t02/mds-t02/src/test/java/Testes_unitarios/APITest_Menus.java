/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testes_unitarios;

import api.API;
import artigos_menus.*;
import java.util.List;
import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author carlos
 */
public class APITest_Menus {
    
  
     private API api;

    @Before
    public void setUp() {
        api = new API();
    }
    
    //Teste unitário para criar menu
    @Test
    public void testEditarNomeMenu() {
        api.criarMenu("Menu do dia");
        api.editarNomeMenu("Menu do dia", "Novo menu");
        List<Menu> menus = api.getMenus();
        assertEquals("Novo menu", menus.get(0).getNome());
    }
    
    //Teste unitário para editar menu
    @Test
    public void testRemoverMenu() {
        api.criarMenu("Menu do dia");
        api.removerMenu("Menu do dia");
        List<Menu> menus = api.getMenus();
        assertEquals(0, menus.size());
    }
    
    //Teste unitário para adicionar artigo ao menu
    @Test
    public void testAdicionarArtigoMenu() {
        api.criarArtigo("hamburger", "hamburger com queijo e bacon", 10.50);
        api.criarMenu("Menu do dia");
        api.adicionarArtigoMenu("Menu do dia", "hamburguer");
        List<Menu> menus = api.getMenus();
        assertEquals(1, menus.get(0).getArtigosMenu().size());
        assertEquals("hamburger", menus.get(0).getArtigosMenu().get(0).getNome());
    }
    
    //Teste unitário para remover artigo do menu
    @Test
    public void testRemoverArtigoMenu() {
        api.criarArtigo("hamburger", "hamburger com queijo e bacon", 10.50);
        api.criarMenu("Menu do dia");
        api.adicionarArtigoMenu("Menu do dia", "hamburguer");
        api.removerArtigoMenu("Menu do dia", "hamburguer");
        List<Menu> menus = api.getMenus();
        assertEquals(0, menus.get(0).getArtigosMenu().size());
    }
}
    
