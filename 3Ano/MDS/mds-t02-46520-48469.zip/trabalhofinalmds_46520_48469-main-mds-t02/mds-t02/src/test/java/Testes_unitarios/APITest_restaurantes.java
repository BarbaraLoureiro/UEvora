/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Testes_unitarios;

import api.API;
import artigos_menus.Menu;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import restaurantes.*;

/**
 *
 * @author carlos
 */


public class APITest_restaurantes {
    private API api;

    @Before
    public void setUp() {
        api = new API();
    }
    
    //Teste unitário para adicionar restaurante
    @Test
    public void testAdicionarRestaurante() {
        api.adicionarRestaurante("Restaurante A", "Endereço A", 123456789, "12:00 - 23:00");
        List<Restaurante> restaurantes = api.getRestaurantes();
        assertEquals(1, restaurantes.size());
        assertEquals("Restaurante A", restaurantes.get(0).getNome());
        assertEquals("Endereço A", restaurantes.get(0).getMorada());
        assertEquals(123456789, restaurantes.get(0).getContacto());
        assertEquals("12:00 - 23:00", restaurantes.get(0).getHorario());
    }
    
    //Teste unitário para editar restaurante
    @Test
    public void testEditarRestaurante() {
        api.adicionarRestaurante("Restaurante A", "Endereço A", 123456789, "12:00 - 23:00");
        api.editarRestaurante("Restaurante A","Restaurante B", "Endereço B", 987654321, "13:00 - 23:00");
        List<Restaurante> restaurantes = api.getRestaurantes();
        assertEquals(1, restaurantes.size());
        assertEquals("Restaurante B", restaurantes.get(0).getNome());
        assertEquals("Endereço B", restaurantes.get(0).getMorada());
        assertEquals(987654321, restaurantes.get(0).getContacto());
        assertEquals("13:00 - 23:00", restaurantes.get(0).getHorario());
    }
    
    //Teste unitário para remover restaurante
    @Test
    public void testRemoverRestaurante() {
        api.adicionarRestaurante("Restaurante A", "Endereço A", 123456789, "12:00 - 23:00");
        api.removerRestaurante("Restaurante A");
        List<Restaurante> restaurantes = api.getRestaurantes();
        assertEquals(0, restaurantes.size());
    }
    
    @Test
    public void testAdicionarMenu() {
        // Criar um restaurante e um menu
        api.adicionarRestaurante("Restaurante A", "Rua X", 123456789, "09:00 - 22:00");
        api.criarMenu("Menu A");
        
        // Adicionar o menu ao restaurante
        api.adicionarMenuRestaurante("Restaurante A", "Menu A");
    
        // Verificar se o menu foi adicionado corretamente
        List<Menu> menus = api.obterMenusDeRestaurante("Restaurante A");
        assertEquals(1, menus.size());
        assertEquals("Menu A", menus.get(0).getNome());
    }
    
    @Test
    public void testRemoverMenu() {
        // Criar um restaurante e um menu
        Restaurante restaurante = new Restaurante("Restaurante A", "Rua X", 123456789, "09:00 - 22:00");
        Menu menu = new Menu("Menu A");
    
        // Adicionar o menu ao restaurante
        api.adicionarMenuRestaurante("Restaurante A", "Menu A");
    
        // Remover o menu do restaurante
        api.removerMenuRestaurante("Restaurante A", "Menu A");
    
        // Verificar se o menu foi removido corretamente
        List<Menu> menus = api.obterMenusDeRestaurante("Restaurante A");
        assertEquals(0, menus.size());
    }
    
    

}