% EX1 - UNIFICAÇÕES -----------------------------------------------------------------------

/*
 ALINEA A -> FALSE

 ALINEA B -> A = banana, R = [morango]

 ALINEA C -> FALSE

 ALINEA D -> A = a, B = [], R = []
 
 ALINEA E -> FALSE

 ALINEA F -> A = a(b,c), X = b

*/


